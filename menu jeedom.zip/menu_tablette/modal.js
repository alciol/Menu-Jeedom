/* This file is part of Jeedom.
*
* Jeedom is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Jeedom is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
*/

"use strict"

var $summaryContainer = null
var modal = null
var modalContent = null

//Dialog summary opening:
$("#md_overviewSummary").dialog({
  closeText: '',
  autoOpen: false,
  modal: true,
  width: 500,
  height: 200,
  position: {my: 'left top', at: 'left+19 top+96', of: window},
  open: function() {
    $('.ui-widget-overlay.ui-front').css('display', 'none')
    //catch infos updates by main mutationobserver (loadpage disconnect/reconnect it):
    if (__OBSERVER__) {
      var summaryModal = document.getElementById('summaryEqlogics')
      __OBSERVER__.observe(summaryModal, _observerConfig_)
    }
  },
  beforeClose: function(event, ui) {
    $('.ui-widget-overlay.ui-front').css('display')
  }
})

$(function() {
  $summaryContainer = $('#summaryEqlogics')
  $summaryContainer.packery()
  modal = $summaryContainer.parents('.ui-dialog.ui-resizable')
  modalContent = modal.find('.ui-dialog-content.ui-widget-content')
  modal.resize(function() {
    $summaryContainer.packery()
  })
  modalContent.off()
  modalContent.off('click').on('click', function (event) {
    if (!$(event.target).parents('.eqLogic-widget').length) {
      $("#md_overviewSummary").dialog('close')
    }
  })

  //history in summary modal:
  modalContent.on({
    'click': function(event) {
      event.stopImmediatePropagation()
      event.stopPropagation()
      if (event.ctrlKey || event.metaKey) {
        var cmdIds = []
        $(this).closest('div.eqLogic-widget').find('.history[data-cmd_id]').each(function () {
          cmdIds.push($(this).data('cmd_id'))
        })
        cmdIds = cmdIds.join('-')
      } else {
        var cmdIds = $(this).closest('.history[data-cmd_id]').data('cmd_id')
      }
      $('#md_modal2').dialog({title: "{{Historique}}"}).load('index.php?v=d&modal=cmd.history&id=' + cmdIds).dialog('open')
    }
  }, 'div.eqLogic-widget .history')
})

function getSummaryHtmlPerso(data, _title) {
  try {
    $summaryContainer.empty().packery('destroy')
  } catch(e) {}
  _title = $.parseHTML('<span>'+_title+'</span>')
  $('.ui-dialog[aria-describedby="md_overviewSummary"] span.ui-dialog-title').empty().append(_title)
  $('#md_overviewSummary').dialog('open')

  var nbEqs = data.length
  for (var i=0; i<nbEqs; i++) {
    jeedom.eqLogic.toHtml({
      id: data[i],
      version: 'dashboard',
      error: function(error) {
        $('#div_alert').showAlert({message: error.message, level: 'danger'})
      },
      success: function(html) {
        if (html.html != '') {
          $summaryContainer.append(html.html)
        }
        nbEqs--

        //is last ajax:
        if (nbEqs == 0) {
          //adapt modal size:
          var brwSize = {
            width: window.innerWidth || document.body.clientWidth,
            height: window.innerHeight || document.body.clientHeight
          }
          var fullWidth = 0
          var fullHeight = 0
          var thisWidth = 0
          var thisHeight = 0
          $('#md_overviewSummary div.eqLogic-widget').each(function(index) {
            thisWidth = $(this).outerWidth(true)
            thisHeight = $(this).outerHeight(true)
            if (fullHeight == 0 || fullHeight < thisHeight + 5) fullHeight = thisHeight + 5
            if ( (fullWidth + thisWidth + 150) < brwSize.width ) {
              fullWidth += thisWidth + 7
            } else {
              fullHeight += thisHeight + 5
            }
          })
          if (fullWidth == 0) {
            fullWidth = 120
            fullHeight = 120
          }
          fullWidth += 6
          fullHeight += 6
          modal.width(fullWidth + 26).height(fullHeight + 50)
          modalContent.width(fullWidth).height(fullHeight)
          $summaryContainer.packery({gutter: 10})

          //second pass for reliability in certain cases:
          fullWidth = $("#summaryEqlogics").width()
          fullHeight = $("#summaryEqlogics").height()
          modal.width(fullWidth + 26).height(fullHeight + 50)
          modalContent.width(fullWidth).height(fullHeight)

          initTooltips($('#md_overviewSummary'))
        }
      }
    })
  }
}