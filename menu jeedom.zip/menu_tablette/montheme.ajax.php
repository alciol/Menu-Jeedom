<?php

  try {
    require_once __DIR__ . '/../../core/php/core.inc.php';

    ajax::init();

    if (init('action') == 'getGlobalSummary') {
      $return = jeeObject::getGlobalSummary(init('key'));
      ajax::success($return);
    }
    
    function ConditionAsText($condition) {
        if (in_array($condition, array('771', '781', '905', '902', '900', '952', '953', '954', '955', '956', '957', '960', '961'))) {
            return "wind";
        } else if (in_array($condition, array('800', '951'))) {
            return "sun";
        } else if ($condition == '909') {
            return "rain";
        }

        switch (substr($condition, 0,1)) {
            case '2':
                return "storm";
            case '3':
                return "mist";
            case '5':
                return "rain";
            case '6':
                return "snow";
            case '7':
                return "mist";
            case '8':
                return "cloud";
        }

        return "default";
    }
    
    if (init('action') == 'ConditionAsText') {
      $cmd_condition = cmd::byEqLogicIdAndLogicalId(init('weatherEqLogicId'), 'condition_id');
      $cmd_sunrise = cmd::byEqLogicIdAndLogicalId(init('weatherEqLogicId'), 'sunrise');
      $cmd_sunset = cmd::byEqLogicIdAndLogicalId(init('weatherEqLogicId'), 'sunset');
      $condition = $cmd_condition->execCmd();
      $sunrise = $cmd_sunrise->execCmd();
      $sunset = $cmd_sunset->execCmd();
      
	  $return['condition'] = ConditionAsText($condition);
      
      $hour = date('Hi');
      if ($hour>=$sunrise && $hour < $sunset) {
        $return['periode'] = "day";
      } else {
        $return['periode'] = "night";
      }
      
      ajax::success($return);
    }

    throw new Exception(__('Aucune méthode correspondante à : ', __FILE__) . init('action'));
    /*     * *********Catch exeption*************** */    
  } catch (Exception $e) {
    ajax::error(displayException($e), $e->getCode());
  }